import React, { useState, useEffect } from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import "./App.css";
import Home from "./Pages/Home";
import NotFound from "./Pages/NotFound";
import Appointment from "./Pages/Appointment";
import { Row, Col, Container } from 'react-bootstrap';




import Login from "./Components/Login";
import Signup from "./Components/Signup";
import ProtectedRoute from "./Components/ProtectedRoute";
import { UserAuthContextProvider } from "./Context/Auth-User";


function App() {
  return (
    <Container style={{ width: "1200px" }}>
      <Row>
        <Col>
          <Router>
            <UserAuthContextProvider>
              <Routes>
                <Route
                  path="/home"
                  element={
                    <ProtectedRoute>
                      <Home />
                    </ProtectedRoute>
                  }
                />
                <Route path="/" element={<Login />} />
                <Route path="/signup" element={<Signup />} />
                <Route path="/" element={<Home />} />
          <Route path="/appointment" element={<Appointment />} />
          <Route path="*" element={<NotFound />} />
              </Routes>
            </UserAuthContextProvider>
          </Router>
        </Col>
      </Row>
    </Container>
  );
}

export default App;
