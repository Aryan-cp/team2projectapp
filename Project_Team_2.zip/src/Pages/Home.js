import React from "react";
import Navbar from "../Components/Navbar";
import About from "../Components/About";
import BookAppointment from "../Components/BookAppointment";
import Footer from "../Components/Footer";

import { Button } from "react-bootstrap";
import { useNavigate } from "react-router";
import { useUserAuth } from "../Context/Auth-User";


function Home() {
  const { logOut, user } = useUserAuth();
  const navigate = useNavigate();
  const handleLogout = async () => {
    try {
      await logOut();
      navigate("/");
    } catch (error) {
      console.log(error.message);
    }
  };
  return (
    <>
      <div className="p-4 box mt-3 text-center">
        Welcome <br />
        {user && user.email}
      </div>
      <div className="d-grid gap-2">

          <Button variant="primary" onClick={handleLogout}>
            Log out
          </Button>

      </div>
      <div className="home-section">
      <Navbar />
      <About />
      <BookAppointment />
      <Footer />
    </div>
    </>
    
  );
}

export default Home;
