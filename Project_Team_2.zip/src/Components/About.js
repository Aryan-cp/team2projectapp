import React from "react";
import Vehicle from "../Assets/red-car-with-insurance-policy-clipboard-contract-guarantee-repairs-event-road_502272-1243.avif";
import SolutionStep from "./SolutionStep";
import "../Styles/About.css";

function About() {
  return (
    <div className="about-section" id="about">
      <div className="about-image-content">
        <img src={Vehicle} alt="InsurancePhoto" className="about-image1" />
      </div>

      <div className="about-text-content">
        <h3 className="about-title">
          <span>About Us</span>
        </h3>
        <p className="about-description">
          Welcome to Vehicle Insurance Website, Here you can apply for the insurance of two wheelers and four wheelers. You can enter the details of your vehicle and can upload the documents regarding the same for applying for Insurance.
        </p>

        <h4 className="about-text-title">Services Available</h4>

        <SolutionStep
          title="Insurance for Two Wheelers"
        />

        <SolutionStep
          title="Insurance for Four Wheelers"
        />
      </div>
    </div>
  );
}

export default About;
