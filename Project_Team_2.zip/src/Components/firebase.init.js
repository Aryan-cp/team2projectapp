
import { initializeApp } from "firebase/app";
import{getAuth} from "firebase/auth";


const firebaseConfig = {
  apiKey: "AIzaSyAPG0lZTgt6KQk8sGMf-8g2Wp4r95u0xc8",
    authDomain: "team2authenticate.firebaseapp.com",
    projectId: "team2authenticate",
    storageBucket: "team2authenticate.appspot.com",
    messagingSenderId: "965057498100",
    appId: "1:965057498100:web:c30e7ca62fd2bc2d6d07a1"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export default app;
