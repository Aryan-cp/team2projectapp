import React from "react";
import "../Styles/Footer.css";
import { Link } from "react-router-dom";

function Footer() {
  return (
    <div className="footer-section">
      <div className="footer-container">
        <div className="ft-info">
          <div className="ft-info-p1">
            <p className="ft-title">
              Vehicle Insurance Company
            </p>
            <p className="ft-description">
              Book your Vehicle Insurance with us. We offer 2 Wheeler and 4 Wheeler Motor
              Vehicle Insurance to our customer. Fill the form and submit the Vehicle
              Insurance Form.
            </p>
          </div>

          <div className="ft-copyright">
            <p>Vehicle Insurance Company Team-2 24th Match 2024</p>
          </div>
      </div>
    </div>
  </div>
  );
}

export default Footer;
