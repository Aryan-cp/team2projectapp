import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import "../Styles/AppointmentForm.css";
import { ToastContainer, toast } from "react-toastify";
import "../Styles/ReactToastify.css";

function AppointmentForm() {
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  });

  const [OwnerName, setOwnerName] = useState("");
  const [OwnerNumber, setOwnerNumber] = useState("");
  const [OwnerAddress, setOwnerAddress] = useState("");
  const [RegistrationNumber, setRegistrationNumber] = useState("");
  const [VehicleClass, setVehicleClass] = useState("");
  const [YearofManufacture, setYearofManufacture] = useState("");
  const [ChasisNumber, setChasisNumber] = useState("");
  const [VehicleModel , setVehicleModel ] = useState("");
  const [VehicleColor, setVehicleColor] = useState("");
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [formErrors, setFormErrors] = useState({});

  const handleSubmit = (e) => {
    e.preventDefault();

    const errors = {};
    if (!OwnerName.trim()) {
      errors.OwnerName = "Name is required";
    } 

    if (!OwnerNumber.trim()) {
      errors.OwnerNumber = "Phone number is required";
    } else if (OwnerNumber.trim().length !== 10) {
      errors.OwnerNumber = "Phone number must be of 10 digits";
    }

    if (VehicleClass === "default") {
      errors.preferredMode = "Please select preferred mode";
    }

    if (Object.keys(errors).length > 0) {
      setFormErrors(errors);
      return;
    }

    setOwnerName("");
    setOwnerNumber("");
    setOwnerAddress("");
    setRegistrationNumber("");
    setVehicleClass("default");
    setYearofManufacture("");
    setChasisNumber("");
    setVehicleModel("");
    setVehicleColor("");

    toast.success("Insurance Form Submitted !", {
      position: toast.POSITION.TOP_CENTER,
    onOpen: () => setIsSubmitted(true),
    onClose: () => setIsSubmitted(false),
    className: 'custom-toast'
    });
  };

  return (
    <div className="appointment-form-section">
      <h1 >
        <Link to="/">
          Insurance Submission Form 
        </Link>
      </h1>

      <div className="form-container">
        <h2 className="form-title">
          <span>Submit the Details </span>
        </h2>

        <form className="form-content" onSubmit={handleSubmit}>
          <label>
            Customer Full Name:
            <input
              type="text"
              value={OwnerName}
              onChange={(e) => setOwnerName(e.target.value)}
              required
            />
            {formErrors.OwnerName && <p className="error-message">{formErrors.OwnerName}</p>}
          </label>

          <br />
          <label>
            Customer Phone Number:
            <input
              type="text"
              value={OwnerNumber}
              onChange={(e) => setOwnerNumber(e.target.value)}
              required
            />
            {formErrors.OwnerNumber && <p className="error-message">{formErrors.OwnerNumber}</p>}
          </label>

          <br />
          <label>
          Vehicle Class:
            <select
              value={VehicleClass}
              onChange={(e) => setVehicleClass(e.target.value)}
              required
            >
              <option value="default">Select</option>
              <option value="2 Wheeler">2 Wheeler</option>
              <option value="4 Wheeler">4 Wheeler</option>
            </select>
            {formErrors.VehicleClass && <p className="error-message">{formErrors.VehicleClass}</p>}
          </label>

          <br />
          <label>
            Year of Manufacture:
            <input
              type="datetime-local"
              value={YearofManufacture}
              onChange={(e) => setYearofManufacture(e.target.value)}
              required
            />
            {formErrors.YearofManufacture && <p className="error-message">{formErrors.YearofManufacture}</p>}
          </label>

          <br />
          <label>
            Chasis Number:
            <input
              type="text"
              value={ChasisNumber}
              onChange={(e) => setChasisNumber(e.target.value)}
              required
            />
            {formErrors.ChasisNumber && <p className="error-message">{formErrors.ChasisNumber}</p>}
          </label>

          <br />
          <label>
            Owner Address:
            <input
              type="text"
              value={OwnerAddress}
              onChange={(e) => setOwnerAddress(e.target.value)}
              required
            />
            {formErrors.OwnerAddress && <p className="error-message">{formErrors.OwnerAddress}</p>}
          </label>

          <br />
          <label>
            Registration Number:
            <input
              type="text"
              value={RegistrationNumber}
              onChange={(e) => setRegistrationNumber(e.target.value)}
              required
            />
            {formErrors.RegistrationNumber && <p className="error-message">{formErrors.RegistrationNumber}</p>}
          </label>

          <br />
          <label>
            Vehicle Model:
            <input
              type="text"
              value={VehicleModel}
              onChange={(e) => setVehicleModel(e.target.value)}
              required
            />
            {formErrors.VehicleModel && <p className="error-message">{formErrors.VehicleModel}</p>}
          </label>

          <br />
          <label>
            Vehicle Colour:
            <input
              type="text"
              value={VehicleColor}
              onChange={(e) => setVehicleColor(e.target.value)}
              required
            />
            {formErrors.VehicleColor && <p className="error-message">{formErrors. VehicleColor}</p>}
          </label>
          
          <br />
          <button type="submit" className="text-appointment-btn">
            Confirm Submission
          </button>

          <p className="success-message" style={{display: isSubmitted ? "block" : "none"}}>Confirmation regarding the Vehicle Insurance has sent to the Mobile Device </p>
        </form>
      </div>

      <div className="legal-footer">
        <p>Vehicle Insurance Company Team-2 - 24th March 2024</p>
      </div>

      <ToastContainer autoClose={5000} limit={1} closeButton={false} />
    </div>
  );
}

export default AppointmentForm;
